//: [Previous](@previous)

import Foundation

func factorial(n: Int) -> Int{return (1...n).reduce(1, combine:*)}

for number in 1..<7 {
    print(number, factorial(number))
}

["a", "b", "c"].joinWithSeparator(", ") // "a, b, c"
print(Array([[1, 2], [1, 2], [1, 2]]
    .joinWithSeparator([0])))
 // [1, 2, 0, 1, 2, 0, 1, 2]

var s = "string"
s.appendContentsOf("Other") // "stringOther"
var x = [1, 2, 3]
x.appendContentsOf([4, 5, 6])
x // [1, 2, 3, 4, 5, 6]

"Hello" + "There" // "HelloThere"

x.insertContentsOf([0, 0], at: 2)
x // [1, 2, 0, 0, 3, 4, 5, 6]

s.insertContentsOf("Foo".characters, at: s.startIndex.advancedBy(1))
s.insert(Character("X"), atIndex: s.startIndex.advancedBy(1))


//: [Next](@next)
