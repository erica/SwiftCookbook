//: [Previous](@previous)

import Foundation

// Recipe 8-10 

extension CollectionType {
    // Return a scrambled index generator
    func generateScrambledIndices() -> AnyGenerator<Self.Index> {
        var indices = Array(startIndex..<endIndex)
        return AnyGenerator {
            if indices.isEmpty {return nil}
            let nextIndex = arc4random_uniform(UInt32(indices.count))
            let nextItem = indices.removeAtIndex(Int(nextIndex))
            return nextItem
        }
    }
    
    // Permutation generator Deprecated in 2.2
    func generateScrambled() -> PermutationGenerator<Self,AnySequence<Self.Index>> {
        return PermutationGenerator(elements: self, indices: AnySequence(generateScrambledIndices()))
    }
}

let letters = "abcdefghijklmnopqrstuvwxyz".characters.map({String($0)})
letters.generateScrambled().forEach{print($0)}

// Recipe 8-11

extension CollectionType {
    func generateWithStride(interval: Self.Index.Distance = 1) -> PermutationGenerator<Self,AnySequence<Self.Index>> {
        var index = startIndex
        let generator:  AnyGenerator<Self.Index> = AnyGenerator {
            defer { index = index.advancedBy(interval, limit: self.endIndex) }
            return index == self.endIndex ? nil : index
        }
        return PermutationGenerator(elements:self, indices: AnySequence(generator))
    }
}

letters.generateWithStride(5).forEach{print($0)}

// Recipe 8-12

extension CollectionType {
    func generateMultiple(count count: Int = 1) -> PermutationGenerator<Self,AnySequence<Self.Index>> {
        var index = startIndex; var current = 0
        let generator:  AnyGenerator<Self.Index> = anyGenerator {
            defer {
                if current + 1 == count {index = index.advancedBy(1, limit: self.endIndex)}
                current = (current + 1) % count
            }
            return index == self.endIndex ? nil : index
        }
        return PermutationGenerator(elements:self, indices: AnySequence(generator))
    }
}

letters.generateMultiple(count: 3).forEach{print($0)}


/*
Update:
*/

/*
extension CollectionType {
    
    /// create a lazy succession of randomly ordered indices
    ///
    /// - returns: random index generator
    func scrambledIndexGenerator() -> AnyGenerator<Self.Index> {
        
        /// The original indices
        var indexArray = Array(indices)
        
        /// The boundary separating available and consumed indices
        var endBoundary: Int = numericCast(count)
        
        /// Build a genetor
        return anyGenerator {
            
            /// Generator completes when indices are exhausted
            if endBoundary == 0 {return nil}
            
            /// Randomly select the next location in the
            /// array of indices to use and adjust the boundary
            let nextIndexIndex = Int(arc4random_uniform(UInt32(endBoundary)))
            
            /// Fetch the index
            let nextIndex = indexArray[Int(nextIndexIndex)]
            
            /// Adjust the boundary
            endBoundary -= 1
            
            /// Move the consumed index after the boundary
            if nextIndexIndex != endBoundary {
                swap(&indexArray[nextIndexIndex], &indexArray[endBoundary])
            }
            
            /// Return the index
            return nextIndex
        }
    }
}
*/

//: [Next](@next)
