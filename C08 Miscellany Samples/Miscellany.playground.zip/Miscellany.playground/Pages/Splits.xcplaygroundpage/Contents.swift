//: [Previous](@previous)

import Foundation

// Recipe 8-7

extension String {
    public func split(
        maxSplit: Int = .max,
        allowEmptySlices: Bool = false,
        @noescape isSeparator:
        (Character) throws -> Bool) rethrows -> [String] {
            return try characters.split(
                maxSplit,
                allowEmptySlices: allowEmptySlices,
                isSeparator: isSeparator)
                .map({String($0)})
    }
    
    public func split(character: Character) -> [String] {
        return split{$0 == character}
    }
}

print("lorem ipsum dolor".split(" ")) // ["lorem", "ipsum", "dolor"]


//: [Next](@next)
