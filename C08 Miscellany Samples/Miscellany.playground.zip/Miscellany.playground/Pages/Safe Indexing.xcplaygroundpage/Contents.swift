//: [Previous](@previous)

import Foundation

// Recipe 8-1
extension Array {
    subscript (safe index: Int) -> Element? {
        return (0..<count).contains(index) ? self[index] : nil
    }
}

// Recipe 8-2
extension Array {
    subscript(i1: Int, i2: Int, rest: Int...) ->  [Element] {
        get {
            var result: [Element] = [self[i1], self[i2]]
            for index in rest {
                result.append(self[index])
            }
            return result
        }
        
        set (values) {
            for (index, value) in zip([i1, i2] + rest, values) {
                self[index] = value
            }
        }
    }
}

var myArray = "abcdefgh".characters.map({String($0)})
myArray[2, 5, 1] // c, f, b
myArray[2, 5, 1] = ["X", "Y", "Z"]
print(myArray) // ["a", "Z", "X", "d", "e", "Y", "g", "h"]

// Recipe 8-3
extension Array {
    subscript (wrap index: Int) -> Element? {
        if count == 0 {return nil}
        return self[(index % count + count) % count]
    }
}

myArray[wrap:-1] // last element

myArray = "abcdefgh".characters.map({String($0)})
let slice = myArray[2...3]
slice.count // 2
slice[2] // "c"

print(slice.enumerate().map({$0})) // count starts at zero for enumeration
slice.startIndex

myArray[2] = "X"
slice[2] // "c"

extension ArraySlice {
    func enumerateWithIndices() -> AnySequence<(Index, Generator.Element)> {
        return AnySequence(zip(indices, self))
    }
}

slice.enumerateWithIndices().forEach{print($0)}

extension CollectionType {
    func enumerateWithIndex() -> AnySequence<(Index, Generator.Element)> {
        var index = startIndex
        return AnySequence {
            return anyGenerator {
                guard index != self.endIndex else { return nil }
                defer {index = index.successor()}
                return (index, self[index])
            }
        }
    }
}


["a":"1", "b":"2", "c":"3"].enumerateWithIndex().forEach{print($0)}

//: [Next](@next)
