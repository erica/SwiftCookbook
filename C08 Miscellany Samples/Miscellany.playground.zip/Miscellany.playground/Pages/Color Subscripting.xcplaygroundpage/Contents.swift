//: [Previous](@previous)

import UIKit

// Recipe 8-4
public typealias RGBColorTuple = (red: CGFloat, green: CGFloat, blue: CGFloat, alpha: CGFloat)
public extension UIColor {
    public var channels: RGBColorTuple? {
        var (r, g, b, a): RGBColorTuple = (0.0, 0.0, 0.0, 0.0)
        let gettableColor = getRed(&r, green: &g, blue: &b, alpha: &a)
        return gettableColor ? (red: r, green: g, blue: b, alpha: a) : nil
    }
    
    public enum RGBAChannel {case Red, Green, Blue, Alpha}
    
    public subscript (channel: RGBAChannel) -> CGFloat {
        switch channel {
        case .Red:   return channels?.red ?? 0.0
        case .Green: return channels?.green ?? 0.0
        case .Blue:  return channels?.blue ?? 0.0
        case .Alpha: return channels?.alpha ?? 0.0
        }
    }
}


let color = UIColor.magentaColor()
color[.Red]   // 1
color[.Green] // 0
color[.Blue]  // 1
color[.Alpha] // 1

public protocol SubscriptPrintable {
    subscript() -> Self {get}
}

public extension SubscriptPrintable {
    subscript() -> Self {
        print(self); return self
    }
}

extension Int: SubscriptPrintable {}

5[] // whee!

//: [Next](@next)
