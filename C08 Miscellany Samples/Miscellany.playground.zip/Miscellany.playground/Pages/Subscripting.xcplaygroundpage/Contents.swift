//: [Previous](@previous)

import Foundation

// Recipe 8-8

extension String {
    public func rangeFromIntRange(range: Range<Int>) -> Range<String.Index> {
        let start = startIndex.advancedBy(range.startIndex)
        let end = startIndex.advancedBy(range.endIndex)
        return start..<end
    }

    public func just(desiredRange: Range<Int>) -> String {
        return substringWithRange(rangeFromIntRange(desiredRange))
    }
    
    public func at(desiredIndex: Int) -> String {
        return just(desiredIndex...desiredIndex)
    }
    
    public func except(range: Range<Int>) -> String {
        var copy = self
        copy.replaceRange(rangeFromIntRange(range), with:"")
        return copy
    }

    // The setters in the following two subscript do not enforce length equality
    // You can replace 1...100 with, for example, "foo"
    public subscript (aRange: Range<Int>) -> String? {
        get {return just(aRange)}
        set {replaceRange(rangeFromIntRange(aRange), with:newValue ?? "")}
    }
    
    public subscript (i: Int) -> String? {
        get {return at(i)}
        set {self[i...i] = newValue}
    }
}

var x = "hello"
x[2]
x[2...3]
x[2...3] = "XXX"
x



//: [Next](@next)
