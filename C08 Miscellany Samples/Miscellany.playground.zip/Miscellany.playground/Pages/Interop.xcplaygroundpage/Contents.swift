//: [Previous](@previous)

import Foundation

// Recipe 8-9

extension String {
    public var ns: NSString {return self as NSString}
}

public extension NSString {
    public var swift: String {return self as String}
}

"/Users/ericasadun/Desktop/file.jpg".ns.lastPathComponent // file.jpg

//: [Next](@next)
