//: [Previous](@previous)

import Foundation

for index in 0...5 {
    if index % 2 != 0 {continue}
    print(index)
}

outerloop: for outer in 0...3 {
    for inner in 0...3 {
        if outer == inner {continue outerloop}
        print(outer, inner)
    }
}

print("Starting")
labelpoint: do {
    // Waits to execute until the scope ends
    defer{print("Leaving do scope")}
    
    // This will always print
    print("Always prints")
    
    // Toss a coin and optionally leave the scope
    let coin = Int(arc4random_uniform(2))
    print("Coin toss: " + (coin == 0 ? "Heads" : "Tails"))
    if coin == 0 {break labelpoint}
    
    // Prints if scope execution continues
    print("Tails are lucky")
}
print("Ending")


//: [Next](@next)
