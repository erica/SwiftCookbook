//: [Previous](@previous)

import Foundation

postfix operator *** {}
postfix func ***<T>(item: T) -> T {print(item); return item}

// /, =, -, +, !, *, %, <, >, &, |, ^, ?, or ~
postfix operator ❗ {} // factorial
postfix func ❗(n: Int) -> Int{return (1...n).reduce(1, combine:*)}
infix operator  ⏬{} // choose
func ⏬(lhs: Int, rhs: Int) -> Int {return lhs❗ / (rhs❗ * (lhs - rhs)❗)}
5 ⏬ 2

// Regex match. Requires Foundation. Don't love it.
infix operator ~== {
    associativity none
    precedence 90
}

func ~==(lhs: String, rhs: String) -> Range<String.Index>? {
    return lhs.rangeOfString(rhs, options: [.RegularExpressionSearch, .CaseInsensitiveSearch], range: lhs.startIndex..<lhs.endIndex, locale: nil)
}


"Hello" ~== "ll"

struct MyStruct {let item: Int}
extension MyStruct: Equatable {}
func ==(lhs: MyStruct, rhs: MyStruct) -> Bool {return lhs.item == rhs.item}

struct MyGenericStruct<T: Equatable> {let item: T}
extension MyGenericStruct: Equatable {}
func ==<T>(lhs: MyGenericStruct<T>, rhs: MyGenericStruct<T>) -> Bool {return lhs.item == rhs.item}



//: [Next](@next)
