//: [Previous](@previous)

import Foundation
import UIKit

// Fetch a range
let string = "My String"
let range = string.rangeOfString("Str")!

let string2 = "Another String"
let result2 = string2.substringWithRange(range) // can seem to work

// It fails with a string that uses different backing traits
let string3 = "😙😚😟😨😧😧😬😫😈😇😚😥😪😯😲😭"
let result3 = string3.substringWithRange(range) // bzzt, returns "�😟"

// This doesn't get you far either
let rStart = range.startIndex.samePositionIn(string3.utf16)
let rEnd = range.endIndex.samePositionIn(string3.utf16)
let adjustedRange = rStart...rEnd
let sub = string3.utf16[rStart..<rEnd]

// Recipe 8-6
extension String {
    func toPortable(range: Range<String.Index>) -> Range<Int> {
        let start = startIndex.distanceTo(range.startIndex)
        let end = startIndex.distanceTo(range.endIndex)
        return start..<end
    }
    
    func fromPortable(range: Range<Int>) -> Range<String.Index> {
        let start = startIndex.advancedBy(range.startIndex)
        let end = startIndex.advancedBy(range.endIndex)
        return start..<end
    }
}

let portableRange = string.toPortable(range)
let threeSpecific = string3.fromPortable(portableRange)
let result4 = string3.substringWithRange(threeSpecific) // correct

//: [Next](@next)
