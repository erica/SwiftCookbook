//: [Previous](@previous)

import Foundation

let s = String(count: 5, repeatedValue: Character("X")) // "XXXXX"
let a = Array(count: 3, repeatedValue: "X") // ["X", "X", "X"]
let a2 = Array(count: 2, repeatedValue: [1, 2]) // [[1, 2], [1, 2]]
let buffer = Array<Int8>(count: 512, repeatedValue: 0)

// Recipe 8-5

extension String {
    var boolValue: Bool {return (self as NSString).boolValue}
}

// Support Swift prefixes (0b, 0o, 0x) and Unix (0, 0x / 0X)
extension String {
    var binaryValue: Int {
        return strtol(self.hasPrefix("0b") ?
            String(self.characters.dropFirst(2)) : self, nil, 2)}
    var octalValue: Int {
        return strtol(self.hasPrefix("0o") ?
            String(self.characters.dropFirst(2)) : self, nil, 8)}
    var hexValue: Int {
        return strtol(self, nil, 16)}
    
    var uBinaryValue: UInt {
        return strtoul(self.hasPrefix("0b") ?
            String(self.characters.dropFirst(2)) : self, nil, 2)}
    var uOctalValue : UInt {
        return strtoul(self.hasPrefix("0o") ?
            String(self.characters.dropFirst(2)) : self, nil, 8)}
    var uHexValue: UInt {
        return strtoul(self, nil, 16)}
    
    //     init(count: Int, repeatedValue c: UnicodeScalar)
    func pad(width: Int, character: Character) -> String {
        return String(count: width - self.characters.count, repeatedValue: character) + self
    }
}

extension Int {
    var binaryString: String {return String(self, radix:2)}
    var octalString: String {return String(self, radix:8)}
    var hexString: String {return String(self, radix:16)}
}

import UIKit
extension String {
    var rgbFromHexTuple: (Int, Int, Int)? {
        if self.characters.count != 6 && self.characters.count != 8 {return nil}
        return (
            self.hexValue >> 16,
            (self.hexValue >> 8) % 0x100,
            self.hexValue % 0x100)
    }
    var rgbFloatFromHexTuple: (CGFloat, CGFloat, CGFloat)? {
        if self.characters.count != 6 && self.characters.count != 8 {return nil}
        return (
            CGFloat(self.hexValue >> 16) / 255.0,
            CGFloat((self.hexValue >> 8) % 0x100) / 255.0,
            CGFloat(self.hexValue % 0x100) / 255.0)
    }
    
}

String(15, radix:2) // 111
String(15, radix:8) // 17
String(15, radix:16) // f

//: [Next](@next)
