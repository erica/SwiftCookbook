//: [Previous](@previous)

import Foundation

let value = "hello"

switch value {
default: break
}

// You can also use void instead
// Not recommended in Swift 2 and later.
switch value {
default: ()
}

switch value {
default: print("Always prints")
}

let intValue = 5
switch intValue {
case 2: print("The value is 2")
case 5: print("The value is 5")
default: print("The value is not 2 or 5")
}

switch value {
case _: print("Always prints")
}

switch intValue {
case 1...3: break
case 4...6:
    if intValue == 5 {break}
    print("4 or 6")
default: break
}

switch intValue {
case 2: print("The value is 2")
case 2: print("The value is still 2, by heavens!")
default: print("The value is not 2")
}

switch intValue {
case 5: print("5"); fallthrough
case 6: print("5 or 6")
case 7: print("7")
default: print("not 5, 6, or 7")
}

switch intValue {
case 5, 6: print("5 or 6")
case 7...12: print("7 - 12")
case 13...15, 17, 19...23:
    print("13, 14, 15, 17, or 19-23")
default: print("Not 5-15, nor 17, nor 19-23")
}

let tup = (3, 15)

switch tup {
case (3, 3): print("Two threes")
case (_, 3), (3, _):
    print("At least one three")
case _: print("No threes")
}

switch tup {
case (0...5, 0...5):
    print("Small positive numbers")
case (0...5, _), (_, 0...5):
    print("At least one small positive number")
default:
    print("No small positive numbers")
}

switch intValue {
case 0...20 where intValue % 2 == 0: print("Even number between 0 and 20")
case 0...20: print("Odd number between 0 and 20")
default: print("Some other number")
}

switch tup {
case let (x, y) where x == y:
    print("tuple items are equal")
case (0, let y) where 0...6 ~= y:
    print("x is 0 and y is between 0 and 6")
default: break
}


switch intValue {
case 0...20 where intValue % 2 == 0: print("Even number between 0 and 20")
case 0...20: print("Odd number between 0 and 20")
default: print("Some other number")
}

for num in 0...10 where num % 2 == 0 {print(num, "is even")}

//: Pattern Matching with Value Bindings
enum Result<T> {
    case Error(ErrorType)
    case Value(Any)
    init(_ t: T) {
        switch t {
        case let error as ErrorType: self = .Error(error)
        default: self = .Value(t)
        }
    }
}

struct CustomError: ErrorType {let reason: String}
print(Result("Hello")) // Value("Hello")
print(Result(CustomError(reason: "Something went wrong")))
    // Error(CustomError(reason: "Something went wrong"))


//: [Next](@next)
