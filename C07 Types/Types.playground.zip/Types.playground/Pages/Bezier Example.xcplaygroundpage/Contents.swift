//: [Previous](@previous)

import UIKit

public struct BezierElement {
    public var elementType: CGPathElementType = CGPathElementType.CloseSubpath
    public var point: CGPoint?
    public var controlPoint1: CGPoint?
    public var controlPoint2: CGPoint?
}

extension BezierElement {
    public var codeValue: String {
        switch (elementType, point, controlPoint1, controlPoint2) {
        case (CGPathElementType.CloseSubpath, _, _, _):
            return "path.closePath()"
        case (CGPathElementType.MoveToPoint, let point?, _, _):
            return "path.moveToPoint(CGPoint(x:\(point.x), y:\(point.y)))"
        case (CGPathElementType.AddLineToPoint, let point?, _, _):
            return "path.addLineToPoint(CGPoint(x:\(point.x), y:\(point.y)))"
        case (CGPathElementType.AddQuadCurveToPoint, let point?,
            let controlPoint1?, _):
            return "path.addQuadCurveToPoint(" +
                "CGPoint(x:\(point.x), y:\(point.y)), " +
                "controlPoint:" +
                "CGPoint(x:\(controlPoint1.x), y:\(controlPoint1.y)))"
        case (CGPathElementType.AddCurveToPoint, let point?,
            let controlPoint1?, let controlPoint2?):
            return "path.addCurveToPoint(" +
                "CGPoint(x:\(point.x), y:\(point.y)), " +
                "controlPoint1:" +
                "CGPoint(x:\(controlPoint1.x), y:\(controlPoint1.y)), " +
                "controlPoint2:" +
                "CGPoint(x:\(controlPoint2.x), y:\(controlPoint2.y)))"
        default: break
        }
        return "Malformed element"
    }
}

var p = BezierElement(elementType: .CloseSubpath, point: nil, controlPoint1: nil, controlPoint2: nil)
print(p.codeValue)
p = BezierElement(elementType: .MoveToPoint, point: CGPoint.zero, controlPoint1: nil, controlPoint2: nil)
print(p.codeValue)
p = BezierElement(elementType: .AddLineToPoint, point: CGPoint.zero, controlPoint1: nil, controlPoint2: nil)
print(p.codeValue)
p = BezierElement(elementType: .AddQuadCurveToPoint, point: CGPoint.zero, controlPoint1: CGPoint.zero, controlPoint2: nil)
print(p.codeValue)
p = BezierElement(elementType: .AddCurveToPoint, point: CGPoint.zero, controlPoint1: CGPoint.zero, controlPoint2: CGPoint.zero)
print(p.codeValue)

// Test generated code
let path = UIBezierPath()
path.closePath()
path.moveToPoint(CGPoint(x:0.0, y:0.0))
path.addLineToPoint(CGPoint(x:0.0, y:0.0))
path.addQuadCurveToPoint(CGPoint(x:0.0, y:0.0), controlPoint:CGPoint(x:0.0, y:0.0))
path.addCurveToPoint(CGPoint(x:0.0, y:0.0), controlPoint1:CGPoint(x:0.0, y:0.0), controlPoint2:CGPoint(x:0.0, y:0.0))

//: [Next](@next)
