//: [Previous](@previous)

import Foundation

enum Dwarf: Int { case Bashful = 1, Doc, Dopey, Grumpy, Happy, Sleepy, Sneezy }

// Recipe 7-2
extension Dwarf: Comparable {}
func <(lhs: Dwarf, rhs: Dwarf) -> Bool {
    return lhs.rawValue < rhs.rawValue
}

var dwarf = Dwarf(rawValue: 5)! // Happy

switch dwarf {
case .Bashful, .Doc, .Dopey, .Grumpy: print("G or lower")
default: print("Dwarf is H or higher")
}

switch dwarf {
case Dwarf.Bashful...Dwarf.Grumpy:
    print("\(dwarf): G or lower")
default:
    print("\(dwarf): H or higher")
}

// Recipe 7-x
// Note: ++ to be removed in Swift 3.0
extension Dwarf {
    static var members: [Dwarf] {
        var items: [Dwarf] = []
        var index = 1
        while let dwarf = Dwarf(rawValue: index) {
            items.append(dwarf)
            index += 1
        }
        return items
    }
    
    static func sequence() -> AnySequence<Dwarf> {
        return AnySequence {
            _ -> AnyGenerator<Dwarf> in
            var index = 1
            return AnyGenerator {
                defer{ index += 1 }
                return Dwarf(rawValue: index)
            }
        }
    }
}

// Thought I'd throw this here to demonstrate something important.
// If you move index = 1 outside AnySequence these next
// few lines return successive rather than identical elements
let s1 = Dwarf.sequence()
let g1 = s1.generate()
let g2 = s1.generate()
print(g1.next())
print(g2.next())

Dwarf.members
for eachDwarf in Dwarf.members {
    print(eachDwarf, terminator: ", ")
}
print("")

Dwarf(rawValue: 0) // nil

//: [Next](@next)
