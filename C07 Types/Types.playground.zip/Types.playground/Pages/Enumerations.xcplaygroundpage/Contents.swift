//: [Previous](@previous)

import Foundation

enum Finger {case Thumb, Index, Middle, Ring, Pinkie}

Finger.Thumb.hashValue // 0
Finger.Middle.hashValue // 2

// Static example for enumeration
extension Finger {
    static func hello() {print("Hello")}
    static var test: String {
        return "Snippet"
    }
}

// Recipe 7-1
extension Finger: Comparable {}
func <(lhs: Finger, rhs: Finger) -> Bool { return lhs.hashValue < rhs.hashValue }

protocol HashableEnumerable {}
extension HashableEnumerable {
    init?(fromHashValue hash: Int) {
        let byte = UInt8(hash)
        self = unsafeBitCast(byte, Self.self)
    }
    
    static func sequence() -> AnySequence<Self> {
        var index = 0
        return AnySequence {
            return anyGenerator {
                index += 1
                return Self(fromHashValue: index)
            }
        }
    }
}

extension Finger: HashableEnumerable {}
Finger(fromHashValue: 2) // Middle
Finger(fromHashValue: 8) // nil
for item in Finger.sequence() {
    print(item)
}

extension Array {
    var randomItem: Element {
        return self[Int(arc4random_uniform(UInt32(count)))]
    }
}
var allFingers = Array(Finger.sequence())
let myFingers = (1...10).map({_ in allFingers.randomItem})
print("My random fingers array is \(myFingers)")

for eachFinger in Finger.sequence() {
    let count = myFingers.filter({$0 == eachFinger}).count
    print(eachFinger, count, separator: "  \t")
}

let finger: Finger = .Index
switch finger {
case .Thumb, .Index, .Middle, .Ring: print("Not pinkie")
default: print("Pinkie")
}

switch finger {
case .Thumb...(.Ring): print("Not pinkie")
default: print("Pinkie")
}

enum Greetings: String {
    case Hello = "Hello, Nurse!"
    case Goodbye = "Hasta la vista"
}

Greetings.Hello.rawValue // Hello, Nurse!
Greetings.Hello.hashValue // 0

Greetings.Goodbye.rawValue // Hast la vista
Greetings.Goodbye.hashValue // 1

Greetings(rawValue: "Hasta la vista")?.hashValue // 1
Greetings(rawValue: "No-op") // nil

enum Clue {
    case End
    case NextClue(Int, String)
}

let nextClue = Clue.NextClue(5, "Go North 5 paces")
if case Clue.NextClue(let step, let directions) = nextClue where step > 2 {
    print("You're almost there!. Next clue: \(directions)")
}

enum TurtleAction {
    case PenUp
    case PenDown
    case Goto(x: Double, y: Double)
    case Turn(degrees: Double)
    case Forward(distance: Double)
}

var actions: Array<TurtleAction> = [.Goto(x:200.0, y:200.0), .PenDown, .Turn(degrees:90.0), .Forward(distance:100.0), .PenUp]

let action = actions[0]; var x = 0.0; var y = 0.0
if case let .Goto(xx, yy) = action {(x, y) = (xx, yy)}
// if case .Goto(let xx,let yy) = action {(x, y) = (xx, yy)}

// Declare for use in immediate scope
guard case let .Goto(a, b) = action else {fatalError()}
print(a, b)

// Recipe 7-3
enum List<T> {
    case Nil
    indirect case Cons(head: T, tail: List<T>)
    
    func dumpIt() {
        switch self {
        case .Cons(head: let car, tail: let cdr):
            print(car); cdr.dumpIt()
        default: break
        }
    }
}

// Construct a list and dump it
var node = List<Int>.Nil
for value in [1, 2, 3, 4, 5] {
    // always adds the new value to the head
    // so the constructed list is 5.4.3.2.1.Nil
    node = List.Cons(head: value, tail: node)
}
node.dumpIt() // prints in reverse order


//: [Next](@next)
