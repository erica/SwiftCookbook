//: [Previous](@previous)

import Foundation

let words = "Lorem ipsum dolor sit amet"
    .characters.split(isSeparator:{$0 == " "})
    .lazy
    .map({
        characters -> String in
        print("Fetching Word")
        return String(characters)
    }) // returns lazy map collection
words.first // prints Fetching Word once
for word in words {
    print(word) // prints Fetching Word before each word
}

// Recipe 7-7
var initialTime = NSDate()
struct MyStruct {
    lazy var item: String = "\(-initialTime.timeIntervalSinceNow)"
//    var item: String = "\(-initialTime.timeIntervalSinceNow)"
}

var instance = MyStruct()
sleep(3)
print(instance.item)

//: [Next](@next)
