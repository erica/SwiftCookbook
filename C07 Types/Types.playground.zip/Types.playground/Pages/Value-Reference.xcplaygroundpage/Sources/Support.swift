import Foundation

public enum Status {case Okay, Error}
public struct Attempt {
    public private(set) var status: Status = .Okay
    public internal(set) var result: String = "Nothing"
    public init() {}
    mutating public func execute() {
        let succeeded = arc4random_uniform(2) > 0
        switch succeeded {
        case true:
            status = .Okay
            result = "Attempt Succeeded"
        case false:
            status = .Error
            result = "Attempt Failed"
        }
    }
}
