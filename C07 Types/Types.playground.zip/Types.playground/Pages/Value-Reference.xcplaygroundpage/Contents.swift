//: Playground - noun: a place where people can play

import UIKit

class MyClass {
    var name: String = "Tom"
    var age: Int = 35
}

struct MyStruct {
    var name: String = "Tom"
    var age: Int = 35
}

let classInstance1 = MyClass()
let classInstance2 = classInstance1
var structInstance1 = MyStruct()
var structInstance2 = structInstance1

classInstance1.age = 88
print(classInstance2.age) // 88
classInstance2.age = 55
print(classInstance1.age) // 55

structInstance1.age = 88
print(structInstance2.age) // 35
structInstance2.age = 55
print(structInstance1.age) // 88

func myFunction(inout myParameter: String) {
    myParameter = "Hello"
}

var myString = "My String"
myFunction(&myString)
print(myString) // Hello

struct MyTest {
    var property: String {
        get {print("getting property"); return "Precomputed"}
        set {print("setting property")}
    }
}

print("Constructing and testing property")
var myTestInstance = MyTest()
myTestInstance.property
print("")

print("You cannot change the property by assignment")
myTestInstance.property = "Try to update but can't"
print(myTestInstance.property) // It is still "Precomputed"
print("")

print("Testing the inout function")
myFunction(&myTestInstance.property)
print(myTestInstance.property) // "Precomputed"
print("")


//: Test attempts (see Support.swift)

var attempt = Attempt()
print(attempt) // Attempt(status: Status.Okay, result: "Nothing")
print(attempt.status) // public get
print(attempt.result) // public get

// Run a few attempts
(1...5).forEach {
    _ in
    attempt.execute()
    print(attempt)
}

// status and result are read-only, but status is private and result is internal
// attempt.status = .Error  // error: value of type 'Attempt' has no member 'status'
// attempt.result = "Test" // Doesn't work either because external sources in a playground are compiled as separate modules
print(attempt.status)
print(attempt.result)