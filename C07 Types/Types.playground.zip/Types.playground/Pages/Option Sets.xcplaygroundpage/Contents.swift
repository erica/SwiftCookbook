//: Playground - noun: a place where people can play

import UIKit

let optionSet: UIRectEdge = [.Left, .Top]
print(optionSet)
print(UIRectEdge.Left)
if optionSet.contains(.Left) {print("Left found")}

var options: UIRectEdge = []
options.insert(.Left)
options.contains(.Left) // true
options.contains(.Right) // false

// Create another set and union
var otherOptions: UIRectEdge = [.Right, .Bottom]
options.unionInPlace(otherOptions)
options.contains(.Right) // true

// Recipe 7-4
struct Features: OptionSetType {
    let rawValue: Int
    static let AlarmSystem = Features(rawValue: 1 << 0)
    static let CDStereo = Features(rawValue: 1 << 1)
    static let ChromeWheels = Features(rawValue: 1 << 2)
    static let PinStripes = Features(rawValue: 1 << 3)
    static let LeatherInterior = Features(rawValue: 1 << 4)
    static let Undercoating = Features(rawValue: 1 << 5)
    static let WindowTint = Features(rawValue: 1 << 6)
}

// Recipe 7-5
extension Features: CustomStringConvertible {
    static var featureStrings = ["Alarm System", "CD Stereo",
        "Chrome Wheels", "Pin Stripes", "Leather Interior",
        "Undercoating", "Window Tint"]
    var description: String {
        return Features.featureStrings.enumerate().lazy
            .filter({(flag, _) in //test membership
                self.contains(Features(rawValue:1<<flag))})
            .map({$0.1}) // extract strings
            .joinWithSeparator(", ") // comma-delineated
    }
}

let carOptions: Features = [.AlarmSystem, .Undercoating, .WindowTint]
print(carOptions) // Alarm System, Undercoating, Window Tint

let featureSet: Features = [.LeatherInterior, .Undercoating]
print(featureSet) // Leather Interior, Undercoating
