//: [Previous](@previous)

import Foundation

enum Container {
    case NilContainer
    case IntContainer(Int)
    case StringContainer(String)
    case DoubleContainer(Double)
}

for c in [.NilContainer,
    .IntContainer(42),
    .StringContainer("Hello!"),
    .DoubleContainer(M_PI)] as [Container] {
        switch c {
        case .NilContainer: print("nil")
        case .DoubleContainer (let d) : print("Double: \(d)")
        case .StringContainer (let s) : print("String: \(s)")
        case .IntContainer (let i): print("Int: \(i)")
        }
}

extension Container {
    var rawValue: Any? {
        switch self {
        case .NilContainer: return nil
        case .DoubleContainer (let d): return d
        case .StringContainer (let s): return s
        case .IntContainer (let i): return i
        }
    }
}

for c in [.NilContainer,
    .IntContainer(42),
    .StringContainer("Hello!"),
    .DoubleContainer(M_PI)] as [Container] {
        print(c.rawValue ?? "nil")
}

extension Container {
    init() {self = .NilContainer}
    init<T>(_ t: T){
        switch t {
        case let value as Int: self = .IntContainer(value)
        case let value as Double: self = .DoubleContainer(value)
        case let value as String: self = .StringContainer(value)
        default: self = .NilContainer
        }
    }
}

for c in [Container(), Container(63),
    Container("Sailor"), Container(M_PI_4)] {
        print(c.rawValue ?? "nil")}

extension Container: CustomStringConvertible {
    var description: String {
        let v = rawValue ?? "nil"; return "\(v)"
    }
}
for c in [Container(), Container(63),
    Container("Sailor"), Container(M_PI_4)] {
        print(c)
}

let items: [Any] = [1, 20, "Hello", 3.5, "Narf", 6, "Weasels"]
let containedItems = items.map({Container($0)})
for case .StringContainer(let value) in containedItems {print("String:", value)}
for case .IntContainer(let value) in containedItems {print("Int:", value)}
for case .DoubleContainer(let value) in containedItems {print("Double:", value)}
//: [Next](@next)
