//: [Previous](@previous)

import Foundation
import UIKit

class MyControllerSubclass: UIViewController {
    var newVar: String = ""
    
    convenience init(newVar: String) {
        self.init(nibName: nil, bundle: nil)
        self.newVar = newVar
    }
}

class MyFailableClass {
    init?() {
        if arc4random_uniform(2) > 0 {return nil}
    }
}

struct Error: ErrorType {}


// Example of throwing initializer
class MyThrowingClass {
    var value: String
    init() {
        value = "Initial value"
    }
    convenience init(string: String) throws {
        if string.isEmpty {throw Error()}
        self.init()
        value = string
    }
}

do {
    // Default constructor
    var instance = MyThrowingClass()
    print("Should get here", instance.value)
    
    // Throwing constructor that succeeds
    instance = try MyThrowingClass(string: "xx")
    print("Should get here", instance.value)
    
    // Throwing constructor that fails
    instance = try MyThrowingClass(string: "")
    print("Should not get here", instance.value)
} catch {
    // The actual error isn't of interest
    print("Error when creating MyThrowingClass")
}

// guard let test = MyFailableClass() else {fatalError()}


enum Items: Int {case First, Second, Third, Fourth, Fifth}

public protocol CountableEnum: Hashable {
    init?(rawValue: Int)
    static func countMembers() -> Int
}

extension CountableEnum {
    static public func countMembers() -> Int {
        let byteCount = sizeof(self)
        if byteCount == 0 {return 1}
        if byteCount > 2 {
            fatalError("Unable to process enumeration")}
        let singleByte = byteCount == 1
        let minValue = singleByte ? 2 : 257
        let maxValue = singleByte ? 2 << 8 : 2 << 16
        for hashIndex in minValue..<maxValue {
            switch singleByte {
            case true:
                if unsafeBitCast(UInt8(hashIndex), self).hashValue == 0 {
                    return hashIndex
                }
            case false:
                if unsafeBitCast(UInt16(hashIndex), self).hashValue == 0 {
                    return hashIndex
                }
            }
        }
        return maxValue
    }
}

extension Items: CountableEnum {}
print(Items.countMembers())


//: [Next](@next)
