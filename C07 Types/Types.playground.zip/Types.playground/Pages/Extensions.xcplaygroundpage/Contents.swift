//: [Previous](@previous)

import UIKit

// Recipe 7-6
public extension CGRect {
    // Init with size
    public init(_ size: CGSize) {
        self.init(origin: CGPoint.zero, size: size)
    }
    
    // Init with origin
    public init(_ origin: CGPoint) {
        self.init(origin: origin, size: CGSize.zero)
    }
    
    // Init with x, y, w, h
    public init(_ x: CGFloat, _ y: CGFloat, _ width: CGFloat, _ height: CGFloat) {
        self.init(x: x, y: y, width: width, height: height)
    }
    
    // Init with doubles
    public init(_ x: Double, _ y: Double, _ width: Double, _ height: Double) {
        self.init(x: x, y: y, width: width, height: height)
    }
    
    // Init with integers
    public init(_ x: Int, _ y: Int, _ width: Int, _ height: Int) {
        self.init(x: x, y: y, width: width, height: height)
    }
    
    // Move origin to .zero
    public var zeroedRect: CGRect {return CGRect(size)}
    
    // Move to center around new origin
    public func aroundCenter(center: CGPoint) -> CGRect {
        let origin = CGPoint(x: center.x - size.width / 2.0,
            y: center.y - size.height / 2)
        return CGRect(origin:origin, size:size)
    }
}

//: [Next](@next)
