//: [Previous](@previous)

import Foundation

struct HandlerStruct {
    let ptr: UnsafeMutablePointer<Void>
    func unsafeFunc() {
        let instance = unsafeBitCast(ptr, MyClass.self)
        print(instance.message)
    }
    
}

class MyClass {
    let message = "Got here"
    
    func test() {
        let ptr = unsafeBitCast(self, UnsafeMutablePointer<Void>.self)
        let handler = HandlerStruct(ptr: ptr)
        
        let numberOfSeconds = 2.0
        let delayTime = dispatch_time(
            DISPATCH_TIME_NOW,
            Int64(numberOfSeconds * Double(NSEC_PER_SEC)))
        
        dispatch_after(delayTime,
            dispatch_get_main_queue()) {
                [self] // capture self
                handler.unsafeFunc()
        }
    }
    
    init() {
        print("Creating instance",
            ObjectIdentifier(self).uintValue)
    }
    
    deinit {
        print("Deallocating instance",
            ObjectIdentifier(self).uintValue)
        CFRunLoopStop(CFRunLoopGetCurrent())
    }
}

MyClass().test()
CFRunLoopRun()
print("Done")

//: [Next](@next)
