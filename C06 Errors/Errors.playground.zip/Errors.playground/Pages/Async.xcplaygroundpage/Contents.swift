//: [Previous](@previous)

import Foundation
import Social

let url = NSURL(string:"http://jsonplaceholder.typicode.com/posts")!
let slrequest = SLRequest(forServiceType: SLServiceTypeFacebook, requestMethod: .POST, URL: url, parameters: [:])

slrequest.performRequestWithHandler {
    (data: NSData!, response: NSHTTPURLResponse!, error: NSError!) -> Void in
    if let string = String(data: data, encoding: NSUTF8StringEncoding) {
        
        // Working version, which should catch an
        // error complaining about permisisons
        do {
            try string.writeToFile("/tmp/test.txt",
                atomically: true,
                encoding: NSUTF8StringEncoding)
        } catch {print (error)}

        // Error version
//        try string.writeToFile("/tmp/test.txt",
//            atomically: true,
//            encoding: NSUTF8StringEncoding)
    }
}

public func dispatch_after(delay: NSTimeInterval, block: () throws -> Void) {
    dispatch_after(
        dispatch_time(DISPATCH_TIME_NOW,
            Int64(delay * NSTimeInterval(NSEC_PER_SEC))),
        dispatch_get_global_queue(
            QOS_CLASS_DEFAULT, 0),
        {
            do {
                try block()
            }
            catch {
                print("Error during async execution")
                print(error)
            }
        }
    )
}

// Change constant for more or less luck
extension String: ErrorType {}
dispatch_after(2.0, block: {
    if arc4random_uniform(2) > 0 {throw "Unlucky"}
    print("This worked")
})

import XCPlayground
XCPlaygroundPage.currentPage.needsIndefiniteExecution = true

//: [Next](@next)
