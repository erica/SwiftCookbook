//: [Previous](@previous)

import Foundation

class ErrorClass: ErrorType{}
ErrorClass()._code // 1
ErrorClass()._domain // "ErrorClass", the type name

struct ErrorStruct: ErrorType{}
ErrorStruct()._code // 1
ErrorStruct()._domain // "ErrorStruct"

enum ErrorEnum: ErrorType {case First, Second, Third}
ErrorEnum.First._code // 0, basically the enum hash value
ErrorEnum.Second._code // 1
ErrorEnum.Third._code // 2
ErrorEnum.First._domain // "ErrorEnum"

do {
    throw ErrorStruct()
} catch { print(error) }

//: [Next](@next)
