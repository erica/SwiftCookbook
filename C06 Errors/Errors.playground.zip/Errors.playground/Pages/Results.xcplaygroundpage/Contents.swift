//: [Previous](@previous)

import Foundation

//: # Recipe 6-5
//: Bypassing try? With a Custom Result Enumeration
//: Keep reloading for different outcomes

struct Issue: ErrorType {let reason: String}

func testForSuccess() -> Bool {
    return arc4random_uniform(2) > 0
}

func myFailableCoinToss() throws -> String {
    if !testForSuccess() {
        throw Issue(reason:"Unlucky!")
    }
    return "Heads!"
}

enum Result<T> {
    case Value(T)
    case Error(ErrorType)
    
    func unwrap() throws -> T {
        switch self {
        case .Value(let value): return value
        case .Error(let error): throw error
        }
    }
    
    var value: T? {
        if case .Value(let value) = self { return value }
        return nil
    }
    
    var error: ErrorType? {
        if case .Error(let error) = self { return error }
        return nil
    }
    
    init(_ block: () throws -> T) {
        do {
            let value = try block()
            self = Result.Value(value)
        } catch {
            self = Result.Error(error)
        }
    }
}

let result = Result(myFailableCoinToss)

switch result {
case .Value(let value): print("Success:", value)
case .Error(let error): print("Failure:", error)
}
if case .Value(let value) = result {
    print("Success:", value)
} else if case .Error(let error) = result {
    print("Failure:", error)
}

// handle error
if let error = result.error {
    print("Error is \(error)")
    // fatalError() // leave scope on error
}

// guard
guard let unwrappedResult = result.value else {
    fatalError("\(result.error!)")
    // leave scope
}

// result is now usable at top level scope
print("Result is \(unwrappedResult)")

//: [Next](@next)
