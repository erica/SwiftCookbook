//: [Previous](@previous)

import Foundation

// fatalError()
// fatalError("Giving up after 5 attempts to connect. Goodbye!")

let index = 5
// assert(index < 10)
assert(index < 10, "Index is out of bounds")

let month = 6
assert(month >= 1 && month <= 12, "Month must be between 1 and 12")

// assertionFailure()
// assertionFailure("Goodbye")

public func simpleAssert(
    @autoclosure condition:  () -> Bool,
    _ message: String) {
        if !condition() {print(message)}
}
simpleAssert(false, "This always triggers")

precondition(index < 10)
precondition(index < 10, "Index is out of bounds")
// preconditionFailure()
// preconditionFailure("Failed")

// abort()
// exit(0)

//: [Next](@next)
