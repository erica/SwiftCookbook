//: [Previous](@previous)

import Foundation

//: # Recipe 6-2
//: Error Context

//: # Recipe 6-2
//: Adding Context to Errors
extension ErrorType {
    public func contextString(
        file: String = __FILE__,
        function: String = __FUNCTION__,
        line: Int = __LINE__) -> String {
            return "\(function):\(file):\(line)"
    }
}

struct CustomError: ErrorType {
    let reason: String
    var context: String = ""
    init(reason: String) {
        self.reason = reason
    }
}

class MyClass {
    static func throwError() throws {
        var err = CustomError(reason: "Something went wrong")
        err.context = err.contextString()
        throw err
    }
}

do { try MyClass.throwError() } catch { print(error) }

func fetchContextString(file: String = __FILE__,
    function: String = __FUNCTION__,
    line: Int = __LINE__) -> String {
        return "\(function):\(file):\(line) "
}

struct MyError: ErrorType {let reason: String}
do {
    throw MyError(reason: fetchContextString() + "Something went wrong")
} catch { print(error) }

extension String: ErrorType {}
do {
    throw fetchContextString() + "Numeric input was out of range"
} catch {print(error)}


//: [Next](@next)
