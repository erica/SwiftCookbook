//: [Previous](@previous)

import Foundation

extension String: ErrorType {}

do {throw "Catch me if you can"} catch { print(error) }

//: [Next](@next)
