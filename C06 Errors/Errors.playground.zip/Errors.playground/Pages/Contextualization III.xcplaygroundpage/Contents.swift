//: [Previous](@previous)

import Foundation

//: # Recipe 6-4
//: Simpler Contextualization

public struct Error: ErrorType {
    let source: String; let reason: String
    public init(_ source: String = #file, _ reason: String) {
        self.reason = reason; self.source = source
    }
}

protocol Contextualizable {}
extension Contextualizable {
    func contextError(
        items: Any...,
        file: String = #file,
        function: String = #function,
        line: Int = #line) -> Error {
            return Error(
                "\(function):\(self.dynamicType):\(file):\(line) ",
                items.map({"\($0)"}).joinWithSeparator(", "))
    }
}

public struct Parent: Contextualizable {
    func myFunction() throws {
        throw contextError("Some good reason", 2, 3)
    }
}

do { try Parent().myFunction() } catch { print(error) }

//: [Next](@next)
