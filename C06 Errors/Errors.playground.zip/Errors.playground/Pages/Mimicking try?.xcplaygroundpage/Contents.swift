//: [Previous](@previous)

import Foundation

//: # Recipe 6-6
//: Printing version of try?

func attempt<T>(block: () throws -> T) -> Optional<T>{
    do {
        return try block()
    } catch {
        print(error)
        return nil
    }
}

extension String: ErrorType {}

func testForSuccess() -> Bool {
    return arc4random_uniform(2) > 0
}

func myFailableCoinToss() throws -> String {
    if !testForSuccess() {
        throw "Unlucky!"
    }
    return "Heads!"
}

if let value = attempt({try myFailableCoinToss()}) {
    print("Value is \(value)")
} else {
    print("Failed")
}

guard let value = attempt({try myFailableCoinToss()}) else {
    print("Quitting")
    fatalError()
}

print("Value was", value)

//: [Next](@next)
