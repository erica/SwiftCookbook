//: [Previous](@previous)

import Foundation

func testForSuccess() -> Bool {
    return arc4random_uniform(2) > 0
}

extension String: ErrorType {}

func myFailableCall() throws {
    if !testForSuccess() {
        throw "Unlucky!"
    }
}

// Reload this page until the call fails
try! myFailableCall()

//: [Next](@next)
