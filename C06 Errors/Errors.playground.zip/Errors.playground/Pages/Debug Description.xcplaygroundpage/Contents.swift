//: [Previous](@previous)

import Foundation

//: # Recipe 6-1
//: Self-describing Error Type
public protocol ExplanatoryErrorType: ErrorType, CustomDebugStringConvertible {
    var reason: String {get}
    var debugDescription: String {get}
}

public extension ExplanatoryErrorType {
    public var debugDescription: String {
        // Adjust for however you want the error to print
        return "\(self.dynamicType): \(reason)"
    }
}

struct MyError: ExplanatoryErrorType {
    let reason: String
}

class FailClass {
    func fail() throws {
        throw MyError(reason: "It was destined")
    }
}

do { try FailClass().fail() } catch { print(error) }

//: [Next](@next)
