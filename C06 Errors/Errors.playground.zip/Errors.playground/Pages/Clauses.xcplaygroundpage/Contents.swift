//: [Previous](@previous)

import Foundation

enum StateError: ErrorType {
    case GeneralError // simple enumeration case
    case UnsupportedState(code: Int, reason: String) // associated values
}

func testForSuccess() -> Bool {
    return arc4random_uniform(2) > 0
}

// Throw an error with associated values
func myFailableCall() throws {
    if !testForSuccess() {
        throw StateError.UnsupportedState(code: 418, reason: "I'm a teapot")}
}

do {
    try myFailableCall()
} catch StateError.GeneralError {
    print("General Error")
} catch StateError.UnsupportedState(let code, let reason) where code == 418 {
        print("Unsupported Coffee state: reason \(reason)")
} catch {
    print("Error is \(error) of some kind")
}

func partiallyHandle() throws -> String {
    do {
        try myFailableCall()
    } catch StateError.UnsupportedState(let code, _) where code == 0 {
        // this will never happen because code is never 0
        return("Error Condition")
    }
    return "Success Condition"
}

func partiallyHandle2() throws -> String {
    try myFailableCall()
    return "Success Condition"
}

func handle() -> String {
    do {
        try myFailableCall()
    } catch {
        return("Error Condition")
    }
    return "Success Condition"
}

//: [Next](@next)
