//: [Previous](@previous)

import Foundation

//: # Recipe 6-3
//: Contextualizing Throwing Types

// Contextual error protocol
public protocol ContextualizedErrorType: ErrorType {
    var source: String {get set}
    var reason: String {get set}
    init(source: String, reason: String)
}

// Enable classes to contextualize their errors
public protocol Contextualizable {}
public extension Contextualizable {
    // This constructor accepts an arbitrary number of items
    public func constructContextError <T:ContextualizedErrorType>(
        errorType: T.Type,
        _ items: Any...,
        file: String = #file,
        function: String = #function,
        line: Int = #line) -> T {
            return T(
                source:"\(function):\(self.dynamicType):\(file):\(line) ",
                reason:items.map({"\($0)"}).joinWithSeparator(", "))
    }
}

// This custom error type conforms to ContextualizedErrorType and can
// be constructed and thrown by types that conform to Contextualizable
public struct CustomErrorType: ContextualizedErrorType {
    public var reason: String
    public var source: String
    public init(source: String, reason: String) {
        self.source = source
        self.reason = reason
    }
}

// The conforming type can build and throw a contextualized error
public struct MyStruct: Contextualizable {
    func myFunction() throws {
        throw constructContextError(
            CustomErrorType.self, "Some good reason", 2, 3)
    }
}

do {try MyStruct().myFunction() } catch { print(error) }

//: [Next](@next)
