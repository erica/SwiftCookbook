//: [Previous](@previous)

import Foundation

public class AuthenticationClass {
    public enum AuthenticationError: ErrorType {
        case InvalidUserCredentials
        case LoginPortalNotEnabled
        case PortalTimeOut(Int)
    }
    
    public func performAuthentication() throws {
        // ... execute authentication tasks ...
        // ... now something has gone wrong ...
        throw AuthenticationError.InvalidUserCredentials
    }
}

do {
    try AuthenticationClass().performAuthentication()
} catch { print(error) }


func someFailableMethod() throws {
    
}

func myPartiallyMitigatingMethod() throws {
    do {
        try someFailableMethod()
    } catch {
        // perform mitigation tasks ...
        // then continue error chain
        throw error
    }
}

//: [Next](@next)
