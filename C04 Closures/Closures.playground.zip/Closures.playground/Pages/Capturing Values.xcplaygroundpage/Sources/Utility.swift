import Foundation

public var n = 5
public func globalFunc() {n += 1; print(n)}
