//: [Previous](@previous)

import Foundation

//: ### Constant and Variable Parameters

// NOTE: Var parameters will be removed in Swift 3.0

func adjustValues(
//    var varParameter varParameter: Int, REMOVED FROM SWIFT
    letParameter letParameter: Int,
    inout inoutParameter: Int) {
//    varParameter++ // updates within function scope
//        letParameter++ // compile-time error
    inoutParameter += 1 // updates within and outside function scope
    print("In Function: \((letParameter, inoutParameter))")
}
var y = 20; var z = 30 // assign
print("Before: \((y, z))") // (20, 30), check
adjustValues(letParameter:y, inoutParameter: &z) // prints (20, 31)
print("After: \((y, z))") // (20, 31) z has now changed

//: [Next](@next)
