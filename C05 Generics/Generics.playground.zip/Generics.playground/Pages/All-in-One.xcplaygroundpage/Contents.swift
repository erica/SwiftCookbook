//: [Previous](@previous)

import UIKit

//: Recipe 5-1

//: Numbers that can be represented as Double instances
public protocol DoubleRepresentable {
    var doubleValue: Double {get}
}

//: Numbers that convert to other types
public protocol ConvertibleNumberType: DoubleRepresentable {}
public extension ConvertibleNumberType {
    public var floatValue: Float {get {return Float(doubleValue)}}
    public var intValue: Int {get {return lrint(doubleValue)}}
    public var CGFloatValue: CGFloat {get {return CGFloat(doubleValue)}}
}

//: Double Representable Conformance
extension Double: ConvertibleNumberType {public var doubleValue: Double {return self}}
extension Int: ConvertibleNumberType {public var doubleValue: Double {return Double(self)}}
extension CGFloat: ConvertibleNumberType {public var doubleValue: Double {return Double(self)}}
extension Float: ConvertibleNumberType {public var doubleValue: Double {return Double(self)}}

//: [Next](@next)
