//: [Previous](@previous)

import Foundation

//: Generic version of testEquality

func testEquality<T:Equatable>(x: T, _ y: T) -> Bool {
    return x == y
}

//: Creating a struct that adopts Equatable

struct Point {
    var x: Double
    var y: Double
}

var p1 = Point(x: 10, y: 30)
var p2 = Point(x: 10, y: 20)
var p3 = Point(x: 10, y: 20)

//: This won't compile (yet) because Point does not conform to Equatable
// testEquality(p1, y: p2) // Will not compile yet

//: So extend Point
extension Point: Equatable {}
func ==(lhs:Point, rhs:Point) -> Bool {
    return lhs.x==rhs.x && lhs.y==rhs.y
}

//: And now it compiles and works
testEquality(p1, p2) // false
testEquality(p1, p1) // true
testEquality(p2, p3) // true

//: [Next](@next)
