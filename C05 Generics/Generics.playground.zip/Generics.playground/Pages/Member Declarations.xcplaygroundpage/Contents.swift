//: [Previous](@previous)

import Foundation

//: What protocols look like

protocol SimplestProtocol {} // requires nothing

protocol ComplexProtocol {
    associatedtype Element
    associatedtype Index: ForwardIndexType
    var readableProperty:  Element {get}
    var readwritableProperty: Element {get set} // setters must also have getters
    static var staticProperty: Index {get}
    func method(parameter: Self) -> Index // same-type parameter
    static func staticMethod() -> Element // class methods for class implementations
    init(element: Element)
    init?(index: Index)
    subscript(index: Index) -> Element {get set} // readwritable
}

//: Required Readonly Property
protocol HasAnIntConstant {var myInt: Int {get}}
class IntSupplier: HasAnIntConstant {let myInt = 2}

//: Mutating
protocol Mutable{mutating func mutate()}
class MutatingClass: Mutable {
    var x = 0; func mutate() {self.x = 999}
}
struct MutatingStruct: Mutable {
    var x: Int; mutating func mutate() {self.x = 999}
}
enum MutatingEnumeration: Mutable {
    case MyCase(Int)
    mutating func mutate() {self = MyCase(999)}
}

var me = MutatingEnumeration.MyCase(0)
if case .MyCase(let x) = me {print(x)} // 0
me.mutate()
if case .MyCase(let x) = me {print(x)} // 999

//: Required Init needs required keyword except for final implementations
protocol InitializableWithString {init(string: String)}

class StringInitializableClass1: InitializableWithString {
    required init(string: String ){}
}

final class StringInitializableClass2: InitializableWithString {
    init(string: String ){}
}

//: [Next](@next)
