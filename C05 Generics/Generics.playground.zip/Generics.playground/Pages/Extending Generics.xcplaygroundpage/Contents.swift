//: [Previous](@previous)

import Foundation

//: # Extending Generic Types
//: Don't know if this will all make the cut for the book but I'm including everything here because it may be of mild interest

extension Array {
    var random: Element? {
        return self.count > 0 ? self[Int(arc4random_uniform(UInt32(self.count)))] : nil
    }
}

extension Array where Element: Hashable {
    func toHashString() -> String {
        var accumulator = ""
        for item in self {accumulator += "\(item.hashValue) "}
        return accumulator
    }
}

print([1.0, 2.5, 6.2].toHashString())

import UIKit
[1.0, 2.5, 6.2].toHashString() // works
// [CGPointMake(2, 3)].toHashString() // Error

// extension Array where Element == Int {} // Not allowed - makes Array non-generic

//: [Next](@next)
