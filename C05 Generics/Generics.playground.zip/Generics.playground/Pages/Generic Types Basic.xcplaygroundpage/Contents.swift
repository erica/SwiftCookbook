//: [Previous](@previous)

import UIKit

//: Basic generic structure
public struct MyStruct <T> {
    let storage: T
}

//: Instantiate with inferred or explicit typing
MyStruct(storage: 15)
MyStruct<String>(storage: "Test")

//: Recipe 5-2
public struct Bunch<Element> {
    private let item: Element
    var count = 1
    
    init(item: Element) {self.item = item}
    
    mutating func push() {count += 1}
    mutating func pop() -> Element? {
        guard count > 0 else {return nil}
        count -= 1
        return item
    }
}

//: Showcase the Bunch behavior with examples
var hellos = Bunch(item: "Hello")
for _ in 1...3 {hellos.push()}
print("Count is now \(hellos.count)")
for _ in 1...4 {print("\(hellos.pop()) \(hellos.count) remaining")}
print("Count is now \(hellos.count)")

//: Declaring multiple protocol conformance
//public struct Thing<Item where Item:Hashable, Item:Comparable> {
//    private let thing: Item
//}

public struct Thing<Item: protocol<Hashable, Comparable>> {
    private let thing: Item
}


Thing(thing:"Hello")
// Thing(thing:CGPoint(x: 5, y:10)) // error

//: Conformances in type constraints don't have to make tons of sense
public struct Thing2<Item where Item:Hashable, Item:Hashable, Item:Hashable, Item:Hashable, Item:Hashable, Item:Comparable> {
    private let thing: Item
}
//: [Next](@next)
