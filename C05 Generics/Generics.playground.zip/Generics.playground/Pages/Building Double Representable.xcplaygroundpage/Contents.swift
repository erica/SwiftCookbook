//: [Previous](@previous)

import Foundation
import UIKit

//: Numbers that can be represented as Double instances
public protocol DoubleRepresentable {
    var doubleValue: Double {get}
}

extension Double: DoubleRepresentable {public var doubleValue: Double {return self}}
extension Int: DoubleRepresentable {public var doubleValue: Double {return Double(self)}}
extension CGFloat: DoubleRepresentable {public var doubleValue: Double {return Double(self)}}
extension Float: DoubleRepresentable {public var doubleValue: Double {return Double(self)}}

//: Use doubleValue to transform intValue
let intValue = 23 // 23
let d = intValue.doubleValue // 23.0
print(d.dynamicType) // Swift.Double
print(d) // 23.0

//: Numbers that convert to other types
public protocol ConvertibleNumberType: DoubleRepresentable {
    var floatValue: Float { get }
    var intValue: Int { get }
    var CGFloatValue: CGFloat { get }
}

public extension ConvertibleNumberType {
    public var floatValue: Float {get {return Float(doubleValue)}}
    public var intValue: Int {get {return lrint(doubleValue)}}
    public var CGFloatValue: CGFloat {get {return CGFloat(doubleValue)}}
}

extension Double: ConvertibleNumberType{}
extension Float: ConvertibleNumberType{}
extension Int: ConvertibleNumberType{}
extension CGFloat: ConvertibleNumberType{}

//: Some examples that showcase the lrint implementation I went with
(23.0).intValue // 23
(22.9).intValue // 23
(22.49).intValue // 22
(22.5).intValue // 22
(22.501).intValue // 23


//: [Next](@next)
