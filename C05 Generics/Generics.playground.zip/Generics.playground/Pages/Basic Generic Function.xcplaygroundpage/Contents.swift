//: ### Basic Generics

import Foundation

//: Compare two integers
func testEqualityInts(x: Int, _ y: Int) -> Bool {
    return x == y
}

testEqualityInts(2, 2) // true
testEqualityInts(2, 3) // false
// testEqualityInts("hello", "hello") // compiler error

//: Compare two equatable values
func testEquality<T where T:Equatable>(x: T, _ y: T) -> Bool {
    return x == y
}

//: Some samples to try this with
testEquality(2, 2) // true
testEquality(2, 3) // false
testEquality("hello", "hello") // true
testEquality(2.3, 2.3) // true
testEquality(true, false) // false
testEquality(1...3, 1...3) // true

//: [Next](@next)
