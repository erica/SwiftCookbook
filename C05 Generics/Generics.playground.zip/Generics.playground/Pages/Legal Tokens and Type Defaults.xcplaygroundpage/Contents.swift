//: [Previous](@previous)

import Foundation

//: Legal Tokens
//class Detail<A, B, C, D, E>
//class Detail<A:ArrayLiteralConvertible, B:BooleanType> {}
protocol SampleProtocol{
    typealias CodeUnit
}

class Detail: SampleProtocol {
    typealias CodeUnit = UInt32
    var i: CodeUnit = 0
}

func sampleFunc1<T:SampleProtocol where T.CodeUnit == UInt16>(x: T) {}
func sampleFunc2<T:SampleProtocol where T.CodeUnit == UInt32>(x: T) {}
// sampleFunc1(Detail()) // does not compile
sampleFunc2(Detail()) // compiles

//: Type Defaults
protocol ArrayOfSelfProtocol {
    typealias ArrayOfSelf: SequenceType = Array<Self>
}

func convertToArray<T: ArrayOfSelfProtocol>(x: T) -> T.ArrayOfSelf {
    return [x] as! T.ArrayOfSelf // works
}

extension Int: ArrayOfSelfProtocol {}
[1, 2, 3] is Int.ArrayOfSelf // true
let result = convertToArray(23)
print(result); print(result.dynamicType)

//: [Next](@next)
