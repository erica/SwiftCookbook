//: [Previous](@previous)

import Foundation

//: Some background stuff. I'll probably ditch this.

//extension CollectionType where Generator.Element: Comparable {
//    var maxIndex: Index? {return self.indices.maxElement({self[$1] > self[$0]})}
//}

// cannot do where U == T
// error: same-type requirement makes generic parameters 'U' and 'T' equivalent

// Same as the next one but collection type moved into where clause
func test<T, U where U:CollectionType, U.Generator.Element == T>(a: T, _ b: U) {
    print("yup: \(a.dynamicType), \(b.dynamicType)")
}

// arguments of T and [T] but second is collection type of any kind not just array
//func test<T, U:CollectionType where U.Generator.Element == T>(a: T, _ b: U) {
//    print("yup: \(a.dynamicType), \(b.dynamicType)")
//}

var array = ["b", "c"]
test("a", array)
var arrayi = [1, 2, 3, 4]
test("a", [1, 2, 3, 4]) // works because Any
test(1, [1, 2, 3, 4])
// test("a", arrayi) // error: String, [Int]

// Multiple protocol conformance
func f1<T where T:IntegerLiteralConvertible, T:Hashable>(x: T) {
    print("just testing")
}

protocol Multi: IntegerLiteralConvertible, Hashable {}
func f2<T: Multi>(x: T) {}


//: [Next](@next)
