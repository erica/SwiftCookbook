//: [Previous](@previous)

import UIKit

//: DeckType is a pretty basic protocol
protocol DeckType {
    func shuffle()
    func deal()
    func matchesDeck(deck: DeckType) -> Bool
}

//: Default implementations let me skip this for the demo that will follow
extension DeckType {
    func shuffle(){}
    func deal(){}
    func matchesDeck(deck: DeckType) -> Bool {return false}
}

//: This implementation is specialized and preferred over the other default
extension DeckType where Self:CollectionType, Self.Generator.Element: Equatable {
    func matchesDeck(deck: DeckType) -> Bool {
        if let deck = deck as? Self {
            if self.count != deck.count {return false}
            return !zip(self, deck).contains({$0 != $1})
        }
        return false
    }
}

//: Magically conform Array to DeckType
extension Array: DeckType {}

// Establish some decks to test with. These are [Int] and [String]
let x = [1, 2, 3, 4]
let y = [1, 2, 3, 4]
let z = [1, 2, 3, 5]
let w = ["a", "b", "c", "d"]

x.matchesDeck(y) // same
x.matchesDeck(z) // different values
x.matchesDeck(w) // different type
x.matchesDeck([1, 2]) // different count

// Build a collection of DeckType items, which may or may not match types (these don't)
var heterogeneousArray: [DeckType] = [] // aka Array<DeckType>()
heterogeneousArray.append(x)
heterogeneousArray.append(w)


//: [Next](@next)
