//: [Previous](@previous)

import Foundation

protocol Basic {}
var basicArray: Array<Basic> = []

// error: protocol 'TypeAliasRequired' can only be used as a generic constraint because it has Self or associated type requirements
protocol TypeAliasRequired {
    typealias Foo
}
//var typeAliasRequiredArray = Array<TypeAliasRequired>() // fail


// error: protocol 'SelfRequired' can only be used as a generic constraint because it has Self or associated type requirements
protocol SelfRequired {
    func something(x: Self)
}
// var selfRequiredArray = Array<SelfRequired>() // fail

extension Int: Basic {}
basicArray.append(5)

// func f(array: [Hashable]) {} // has self requirements
func f<T:Hashable>(array: [T]) {} // works

//: [Next](@next)
