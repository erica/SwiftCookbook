//: [Previous](@previous)

import Foundation

//: Constraints limit this class to store Int collections
public class Notion<C:CollectionType where C.Generator.Element==Int> {
    var collectionOfInts: C
    init(collection: C) {self.collectionOfInts = collection}
}

let notion = Notion(collection: [1, 2, 3]) // works
// let notion = Notion(collection: ["a", "b", "c"]) // doesn't work

//: You cannot constrain same-type between simple tokens
enum Pointed<T, U>{case X(T), Y(U)} // works
// enum Pointed<T, U where T==U>{case X(T), Y(U)} // error: same-type requirement makes generic parameters 'T' and 'U' equivalent

//: Recipe 5-3
func customMember<Element: Equatable, C: CollectionType where C.Generator.Element == Element>(collection: C, element: Element) -> Bool {
    return collection.map({$0 == element}).contains(true)
}

let memberArray = [1, 2, 3, 4, 5, 6]
customMember(memberArray, element: 2) // true
customMember(memberArray, element: 17) // false
// CustomMember(memberArray, element: "hello") // compiler error

//: Recipe 5-4
//func uniq<S: SequenceType, T: Hashable where S.Generator.Element == T>(source: S) -> [T] {
//    return Array(Set(source))
//}

//: Equivalent
func uniq<S: SequenceType where S.Generator.Element:Hashable>(source: S) -> [S.Generator.Element] {
    return Array(Set(source))
}

//: Better
extension SequenceType where Generator.Element:Hashable {
    func uniq() -> Array<Generator.Element> {
        return Array(Set(self))
    }
}

//: What the heck. Redesign the pointless customMember function too.
//: Genericize all the things!
extension CollectionType where Generator.Element:Equatable {
    func customMember(element: Generator.Element) -> Bool {
        return self.map({$0 == element}).contains(true)
    }
}

print(uniq([1, 3, 5, 1, 1, 3, 1, 2]))
print([1, 3, 5, 1, 1, 3, 1, 2].uniq())
memberArray.customMember(2)
memberArray.customMember(15)

//: [Next](@next)
