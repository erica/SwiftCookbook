//: [Previous](@previous)

import Foundation

//: Session 408. This no longer applies. Move along, move along.
//: I left this in here because if you watched the video, this may be useful to reference

protocol TestProtocol {
//    func doSomething() // declared. Comment out for non-declared.
}

extension TestProtocol {
    func doSomething() {
        print("Print default implementation")
    }
}

struct MyStruct: TestProtocol {
    func doSomething() {
        print("Custom implementation")
    }
}

let s = MyStruct() // Type is MyStruct
s.doSomething()

let s2: TestProtocol = MyStruct() // Type is TestProtocol
s.doSomething()

//: [Next](@next)
