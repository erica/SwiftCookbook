//: [Previous](@previous)

import Foundation

//: Again of general interest, probably will be cut from the book

public protocol SubscriptPrintable {
    subscript() -> Self {get}
}

public extension SubscriptPrintable {
    subscript() -> Self {
        print(self); return self
    }
}

extension Int: SubscriptPrintable {}

let x = 5[] + 10 // prints 5, returns 15

//: This is a superior solution because it works for all types
postfix operator *** {}
postfix func ***<T>(object: T) -> T {
    print(object); return object
}

//: You don't get too far with Any/AnyObject and protocols
// extension AnyObject: SubscriptPrintable{} // nope
// extension Any: SubscriptPrintable{} // nope

//: [Next](@next)
